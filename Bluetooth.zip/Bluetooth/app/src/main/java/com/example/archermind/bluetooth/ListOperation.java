package com.example.archermind.bluetooth;

import java.util.List;

public class ListOperation {

    public boolean myEquals(List<Blue> list, Blue b){

        for(Blue blue:list)
        {
            if(blue.getAddress().equals(b.getAddress())){
                return false;
            }
        }
        return true;
    }
}
