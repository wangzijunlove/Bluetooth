package com.example.archermind.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.util.List;

import static android.content.Context.BLUETOOTH_SERVICE;

public class BleScan {
       //搜索状态的标示
        private  BluetoothLeScanner scannerBle;
        private  ScanCallback leCallback;
        private boolean mScanning = true;
        private Context context;
     @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
     public void getInitialization(Context context) {
         final BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(BLUETOOTH_SERVICE);
         BluetoothAdapter mBluetoothAdapter = bluetoothManager.getAdapter();
         scannerBle = mBluetoothAdapter.getBluetoothLeScanner();
         mBluetoothAdapter.enable();



         leCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                super.onScanResult(callbackType, result);
                BluetoothDevice device = result.getDevice();
                Log.d("Blescan", "开始扫描BLE");
                Blue blueBle = new Blue(device.getName(), device.getAddress());
                Message msg = new Message();
                msg.what = 4;
                Bundle bundleBle = new Bundle();
                bundleBle.putSerializable("BLE", blueBle);
                msg.setData(bundleBle);
                Handler handler = MainActivity.handlerOPeration.getHandler();
                handler.sendMessage(msg);
            }

            @Override
            public void onBatchScanResults(List<ScanResult> results) {
                super.onBatchScanResults(results);
            }

            @Override
            public void onScanFailed(int errorCode) {
                super.onScanFailed(errorCode);
                Log.e("BleScan", "搜索失败");
            }
        };
    }
    /**
     * 开启蓝牙
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void startBlue(){
        if(mScanning){
            mScanning = false;
            //开始扫描并设置回调
            scannerBle.startScan(leCallback);
        }
    }

    /**
     * 停止蓝牙扫描
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void stopBlue(){
        if(!mScanning){
            //结束蓝牙扫描
            mScanning=true;
            scannerBle.stopScan(leCallback);

        }
    }



}
