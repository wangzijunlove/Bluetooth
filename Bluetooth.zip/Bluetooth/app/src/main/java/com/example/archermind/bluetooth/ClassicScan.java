package com.example.archermind.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.os.Message;
import android.os.Bundle;
import android.os.Handler;

import java.util.ArrayList;
import java.util.List;

public class ClassicScan extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if(BluetoothDevice.ACTION_FOUND.equals(intent.getAction()))
        {
            BluetoothDevice device=intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if(device.getAddress()!=null)
            {
                Blue blueClassic=new Blue(device.getName(),device.getAddress());
                Message msg = new Message();
                msg.what =5;
                Bundle bundleClassic = new Bundle();
                bundleClassic.putSerializable("CLASSIC", blueClassic);
                msg.setData(bundleClassic);
                Handler handler=MainActivity.handlerOPeration.getHandler();
                handler.sendMessage(msg);
            }

        }else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(intent.getAction())) {
            Log.d("ClassicScan","开始搜索");
        } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(intent.getAction())) {
            Log.d("ClassicScan","完成搜索");
        }

    }





}