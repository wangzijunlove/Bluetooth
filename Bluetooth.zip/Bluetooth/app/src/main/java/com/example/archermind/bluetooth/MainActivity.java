package com.example.archermind.bluetooth;
import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    private  List<Blue> listClassic = new ArrayList<>();
    private  List<Blue> listBle = new ArrayList<>();
    private Button button;
    private  BlueAdapter blueAdapterClassic,blueAdapterBle;
    static HandlerOPeration handlerOPeration=new HandlerOPeration();
    private BluetoothAdapter blueToothAdapter = BluetoothAdapter.getDefaultAdapter();
    private ListView listViewClassic = null, listViewBle = null;
    private static final int REQUEST_PERMISSION_ACCESS_LOCATION = 1;
    private boolean flag = false;
    private boolean mReceiverTag = false;
    ClassicScan myReceive = new ClassicScan();
    private BleScan blescan=new BleScan();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.btn_main);
        listViewClassic = findViewById(R.id.list_classic);
        listViewBle=findViewById(R.id.list_ble);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag == true) {
                    button.setText(MainActivity.this.getString(R.string.scan));
                    mhandler.sendEmptyMessageDelayed(0,0);
                    flag = false;
                } else {
                    listClassic.clear();
                    listBle.clear();
                    if (mReceiverTag == false) {
                        registerBroadcast();
                        mReceiverTag = true;
                        Log.e("MainActivity","执行了注册");
                    }
                    mhandler.sendEmptyMessageDelayed(2,30000);
                    mhandler.sendEmptyMessageDelayed(0,60000);
                    mhandler.sendEmptyMessage(1);
                    blueAdapterClassic = new BlueAdapter(listClassic, MainActivity.this);
                    blueAdapterBle=new BlueAdapter(listBle,MainActivity.this);
                    listViewBle.setAdapter(blueAdapterBle);
                    listViewClassic.setAdapter(blueAdapterClassic);
                    Log.d("MainActivity", "开始扫描");
                    button.setText(MainActivity.this.getString(R.string.stop));
                    flag = true;
                }

            }
        });
    }

    public  Handler mhandler = new Handler(new Handler.Callback() {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public boolean handleMessage(Message msg) {
            ListOperation listOperation = new ListOperation();
            handlerOPeration.setHandler(mhandler);
            switch (msg.what) {
                case 5:  //根据上面的提示，当Message为1，表示数据处理完了，可以通知主线程了
                    Blue user = (Blue) msg.getData().getSerializable("CLASSIC");
                    if(listOperation.myEquals(listClassic,user)==true){
                        listClassic.add(user);
                        blueAdapterClassic.notifyDataSetChanged();
                        Log.d("MainActivitylistview1", "姓名" + user.getName() + "地址  " + user.getAddress());
                        break;
                    }
                    break;
                case 4:
                    Blue ble = (Blue) msg.getData().getSerializable("BLE");
                    if(listOperation.myEquals(listBle,ble)==true){
                        listBle.add(ble);
                        blueAdapterBle.notifyDataSetChanged();
                        Log.d("MainActivitylistview2", "姓名" + ble.getName() + "地址  " + ble.getAddress());
                        break;
                    }
                    break;
                case 2:
                    if (mReceiverTag == true) {
                        unregisterReceiver(myReceive);
                       // Log.e("MainActivity", "执行了注销");
                        mReceiverTag = false;
                    }
                    if(flag == true) {

                        blescan.getInitialization(MainActivity.this);
                        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
                            Log.e("MainActivity", "支持BLE");
                        } else {
                            Log.e("MainActivity", "bu支持BLE");
                        }

                        blescan.startBlue();
                        Toast.makeText(MainActivity.this, MainActivity.this.getString(R.string.startble), Toast.LENGTH_SHORT).show();
                        break;
                    }else {
                        break;
                    }
                case 1:
                    Toast.makeText(MainActivity.this,MainActivity.this.getString(R.string.startclassic),Toast.LENGTH_SHORT).show();
                    blueToothAdapter.enable();//打开
                    requestPermission();
                    break;
                case 0:
                    mhandler.removeMessages(0);
                    mhandler.removeMessages(1);
                    mhandler.removeMessages(2);
                    blueToothAdapter.cancelDiscovery();//经典蓝牙结束扫描
                    blescan.stopBlue();//低功耗蓝牙结束扫描
                    button.setText(MainActivity.this.getString(R.string.scan));
                    flag = false;
                    Log.d("ClassicScan", "停止");
                    break;
                default:
                    break;
            }

            return false;
        }
    });

    /**
     * 开启经典蓝牙扫描
     */
    public void search() {
        if (blueToothAdapter.isDiscovering())
            blueToothAdapter.cancelDiscovery();
        blueToothAdapter.startDiscovery();
        //Log.e("MAinActivity","执行了Discovery  ");
    }

    /**
     * 开启权限
     */
    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            int checkAccessFinePermission = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
            if (checkAccessFinePermission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_PERMISSION_ACCESS_LOCATION);
                Log.e(getPackageName(), "没有权限，请求权限");
                return;
            }
            Log.e(getPackageName(), "已有定位权限");
            search();
        }
    }

    /**
     * 开启权限
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.e(getPackageName(), "开启权限permission granted!");
                    //做下面该做的事
                    search();
                } else {
                    Log.e(getPackageName(), "没有定位权限，请先开启!");
                }
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    /**
     * 注册广播
     */
    private void registerBroadcast() {
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(myReceive, filter);
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(myReceive, filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mReceiverTag == true){
            unregisterReceiver(myReceive);//注销广播
            mReceiverTag = false;
        }
        blueToothAdapter.disable();//停止蓝牙
    }
}