package com.example.archermind.bluetooth;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class BlueAdapter extends BaseAdapter {
    private Context mcontext;
    private LayoutInflater layoutInflater;
    private List<Blue> list=new ArrayList<>();

    public BlueAdapter(List<Blue> list , Context context) {
        this.list = list;
        this.mcontext = context;
        layoutInflater = LayoutInflater.from(context);//context :要使用当前的Adapter的界面对象 layoutInflater: 布局装载器对象
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    class ViewHolder {

        TextView deviceName;
        TextView deviceAddress;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            viewHolder = new ViewHolder();
            view = layoutInflater.inflate(R.layout.listadapter,null);
            viewHolder.deviceName = (TextView) view.findViewById(R.id.text_name);
            viewHolder.deviceAddress = (TextView) view.findViewById(R.id.text_address);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        Blue blue = list.get(i);
        final String deviceName = blue.getName();
        if (deviceName != null && deviceName.length() > 0) {
            viewHolder.deviceName.setText(mcontext.getString(R.string.name)+ blue.getName());
        } else {
            viewHolder.deviceName.setText(mcontext.getString(R.string.noname));
        }
        viewHolder.deviceAddress.setText(mcontext.getString(R.string.macaddress)+ blue.getAddress());
        return view;

    }
}
