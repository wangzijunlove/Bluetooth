package com.example.archermind.bluetooth;

import android.app.Application;
import android.os.Handler;

public class HandlerOPeration extends Application {
    private Handler myHandler;
    @Override
    public void onCreate()
    {

        super.onCreate();
    }

    //该方法用于保存要传递的handler
    public void setHandler( Handler handler) {

        this.myHandler = handler;
    }
    //该方法用于获取要传递的handler
    public Handler getHandler() {

        return myHandler;
    }
}
